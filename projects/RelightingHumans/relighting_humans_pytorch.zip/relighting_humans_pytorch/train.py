#!/usr/bin/env python
# coding: utf-8

from glob import glob
import numpy as np
np.random.seed(1234)
import skimage.morphology
import cv2
import os
import sys
import random
import time
import model
import torch
import torch.nn.functional as F
from tqdm import tqdm
import argparse


parser = argparse.ArgumentParser(description='Relighting humans')
parser.add_argument('--gpu', '-g', default=-1, type=int, help='GPU ID (negative value means CPU)')
parser.add_argument('--max_epochs', default=60, type=int, help='Max number of epochs')
parser.add_argument('--train_dir', '-i', default='train_inputs', help='Directory for training input images')
parser.add_argument('--test_dir', '-t', default='test_inputs', help='Directory for test input images')
parser.add_argument('--out_dir', '-o', default='outputs', help='Directory for output images')
parser.add_argument('--train_light_dir', '-l0', default='train_lights', help='Light directory for training')
parser.add_argument('--test_light_dir', '-l1', default='test_lights', help='Light directory for test')
parser.add_argument('--w_transport', '-tw0', default=1., type=float, help='')
parser.add_argument('--w_albedo', '-tw1', default=1., type=float, help='')
parser.add_argument('--w_light', '-tw2', default=1., type=float, help='')
parser.add_argument('--w_transport_tv', '-tw3', default=1., type=float, help='')
parser.add_argument('--w_albedo_tv', '-tw4', default=1., type=float, help='')
parser.add_argument('--w_shading_transport', '-tw5', default=1., type=float, help='')
parser.add_argument('--w_shading_light', '-tw6', default=1., type=float, help='')
parser.add_argument('--w_shading_all', '-tw7', default=1., type=float, help='')
parser.add_argument('--w_rendering_albedo', '-tw8', default=1., type=float, help='')
parser.add_argument('--w_rendering_transport', '-tw9', default=1., type=float, help='')
parser.add_argument('--w_rendering_light', '-tw10', default=1., type=float, help='')
parser.add_argument('--w_rendering_albedo_transport', '-tw11', default=1., type=float, help='')
parser.add_argument('--w_rendering_transport_light', '-tw12', default=1., type=float, help='')
parser.add_argument('--w_rendering_albedo_light', '-tw13', default=1., type=float, help='')
parser.add_argument('--w_rendering_all', '-tw14', default=1., type=float, help='')

args = parser.parse_args()

traindir_path = args.train_dir if args.train_dir[:-1] == '/' else args.train_dir + '/'
testdir_path = args.test_dir if args.test_dir[:-1] == '/' else args.test_dir + '/'
outdir_path = args.out_dir if args.out_dir[:-1] == '/' else args.out_dir + '/'
train_light_path = args.train_light_dir if args.train_light_dir[:-1] == '/' else args.train_light_dir + '/'
test_light_path = args.test_light_dir if args.test_light_dir[:-1] == '/' else args.test_light_dir + '/'

if not os.path.exists(outdir_path):
    os.makedirs(outdir_path)

model_save_path = outdir_path + 'shared_model_%03d.pth'
opt_save_path = outdir_path + 'shared_opt_%03d.pth'

gpu = args.gpu
max_epoch = args.max_epochs
batch_size = 1 

w_transport = args.w_transport
w_albedo = args.w_albedo
w_light = args.w_light
w_transport_tv = args.w_transport_tv
w_albedo_tv = args.w_albedo_tv
w_shading_transport = args.w_shading_transport
w_shading_light = args.w_shading_light
w_shading_all = args.w_shading_all
w_rendering_albedo = args.w_rendering_albedo
w_rendering_transport = args.w_rendering_transport
w_rendering_light = args.w_rendering_light
w_rendering_albedo_transport = args.w_rendering_albedo_transport
w_rendering_transport_light = args.w_rendering_transport_light
w_rendering_albedo_light = args.w_rendering_albedo_light
w_rendering_all = args.w_rendering_all

train_fpath  = glob(traindir_path+"*_tex.png")
train_light_fpath = glob(train_light_path+'*.npy')
test_fpath = glob(testdir_path+"*_tex.png")
test_light_fpath = glob(test_light_path+'*.npy')

if len(train_fpath) == 0:
    print('Error: no training images')
    exit(-1)

if len(train_light_fpath) == 0:
    print('Error: no training lights')
    exit(-1)

if len(test_fpath) == 0:
    print('Error: no test images')
    exit(-1)

if len(test_light_fpath) == 0:
    print('Error: no test lights')
    exit(-1)

m_shared = model.CNNAE2ResNet()
o_shared = torch.optim.Adam(m_shared.parameters(),lr=0.0002, betas=(0.5, 0.999))

def save_shading_image(light_transport_map, light, filename):
    cv2.imwrite(filename, 255 * np.matmul(light_transport_map, light))

def infer_light_transport_albedo_and_light(img, mask):
    img = 2.*img-1.
    img = img.transpose(2,0,1)
    mask3 = mask[None,:,:].repeat(3,axis=0).astype(np.float32)
    mask9 = mask[None,:,:].repeat(9,axis=0).astype(np.float32)

    img = torch.from_numpy(img.astype(np.float32)).clone()
    mask3 = torch.from_numpy(mask3.astype(np.float32)).clone()
    mask9 = torch.from_numpy(mask9.astype(np.float32)).clone()

    if gpu>-1:
        img = img.to("cuda")
        mask3 = mask3.to("cuda")
        mask9 = mask9.to("cuda")

    with torch.no_grad():
        img_batch = img[None,:,:,:].clone()
        mask3_batch = mask3[None,:,:,:].clone()
        mask9_batch = mask9[None,:,:,:].clone()

    img_batch = mask3_batch * img_batch

    res_transport, res_albedo, res_light = m_shared(img_batch)

    res_transport = (mask9_batch * res_transport).data[0]
    res_albedo = (mask3_batch * res_albedo).data[0]

    res_light = res_light.data
    
    if gpu>-1:
        res_transport = res_transport.to("cpu")
        res_albedo = res_albedo.to("cpu")
        res_light = res_light.to("cpu")

    res_transport = res_transport.detach().numpy().copy()
    res_albedo = res_albedo.detach().numpy().copy()
    res_light = res_light.detach().numpy().copy()
    
    res_transport = res_transport.transpose(1,2,0)
    res_albedo = res_albedo.transpose(1,2,0)

    return res_transport, res_albedo, res_light


if gpu>-1:
    m_shared = m_shared.to("cuda") 


N_train_img = len(train_fpath)
N_train_light = len(train_light_fpath)
N_train_total = N_train_img * N_train_light

N_test_img = len(test_fpath)
N_test_light = len(test_light_fpath)
N_test_total = N_test_img * N_test_light

print('Preloading %d lights ...' % (N_train_light + N_test_light))

train_lights = []
for train_light_path in train_light_fpath:
    light = np.load(train_light_path)
    light = torch.from_numpy(light.astype(np.float32)).clone()
    if gpu>-1:
        light = light.to("cuda")
    train_lights.append(light)

test_lights = []
for train_light_path in test_light_fpath:
    light = np.load(train_light_path)
    light = torch.from_numpy(light.astype(np.float32)).clone()
    if gpu>-1:
        light = light.to("cuda")
    test_lights.append(light)

v_kernel = np.zeros((9,9,3,3),dtype=np.float32)
h_kernel = v_kernel.copy()
v_kernel[np.identity(9).astype(np.bool)] = np.array([[0,1,0],[0,-1,0],[0,0,0]], dtype=np.float32)
h_kernel[np.identity(9).astype(np.bool)] = np.array([[0,0,0],[0,-1,1],[0,0,0]], dtype=np.float32)
v_kernel =  torch.from_numpy(v_kernel.astype(np.float32)).clone()
h_kernel =  torch.from_numpy(h_kernel.astype(np.float32)).clone()

if gpu>-1:
    v_kernel = v_kernel.to("cuda")
    h_kernel = h_kernel.to("cuda")
    
v_kernel3 = np.zeros((3,3,3,3),dtype=np.float32)
h_kernel3 = v_kernel3.copy()
v_kernel3[np.identity(3).astype(np.bool)] = np.array([[0,1,0],[0,-1,0],[0,0,0]], dtype=np.float32)
h_kernel3[np.identity(3).astype(np.bool)] = np.array([[0,0,0],[0,-1,1],[0,0,0]], dtype=np.float32)
v_kernel3 =  torch.from_numpy(v_kernel3.astype(np.float32)).clone()
h_kernel3 =  torch.from_numpy(h_kernel3.astype(np.float32)).clone()
if gpu>-1:
    v_kernel3 = v_kernel3.to("cuda")
    h_kernel3 = h_kernel3.to("cuda")


for epoch in range(max_epoch):
    print('[%s] epoch: %d, gpu: %d\n  outdir: %s' % (sys.argv[0], epoch, gpu, outdir_path))
    start_epoch = time.time()
    
    L_sum = 0.
    L_transport_sum = 0.
    L_albedo_sum = 0.
    L_light_sum = 0.
    L_transport_tv_sum = 0.
    L_albedo_tv_sum = 0.
    L_shading_transport_sum = 0.
    L_shading_light_sum = 0.
    L_shading_all_sum = 0.
    L_rendering_albedo_sum = 0.
    L_rendering_transport_sum = 0.
    L_rendering_light_sum = 0.
    L_rendering_albedo_transport_sum = 0.
    L_rendering_transport_light_sum = 0.
    L_rendering_albedo_light_sum = 0.
    L_rendering_all_sum = 0.
    perm_img = np.random.permutation(N_train_img)
    perm_light = np.random.permutation(N_train_light)
    
    pbar = tqdm(total=N_train_total, desc='  train', ascii=True)
    for bi in range(N_train_img):
        for i in perm_img[bi:bi+1]:
            albedo = cv2.imread(train_fpath[i], cv2.IMREAD_COLOR).astype(np.float32) / 255.
            mask = cv2.imread(train_fpath[i][:-7]+"mask.png", cv2.IMREAD_GRAYSCALE).astype(np.float32) / 255.
            eroded_mask = skimage.morphology.binary_erosion(mask).astype(np.float32)
            transport = np.load(train_fpath[i][:-7]+"transport.npz")['T']

            albedo = torch.from_numpy(albedo.astype(np.float32)).clone()
            mask = torch.from_numpy(mask.astype(np.float32)).clone()
            eroded_mask = torch.from_numpy(eroded_mask.astype(np.float32)).clone()
            transport = torch.from_numpy(transport.astype(np.float32)).clone()

            if gpu>-1:
                albedo = albedo.to("cuda")
                mask = mask.to("cuda")
                eroded_mask = eroded_mask.to("cuda")
                transport = transport.to("cuda")
            
            albedo_batch = albedo.permute(2,0,1)[None,:,:].contiguous()
            erode3_batch = torch.repeat_interleave(eroded_mask[None,:,:],3,dim=0)[None,:,:,:].contiguous()
            erode9_batch = torch.repeat_interleave(eroded_mask[None,:,:],9,dim=0)[None,:,:,:].contiguous()
            mask3_batch = torch.repeat_interleave(mask[None,:,:],3,dim=0)[None,:,:,:].contiguous()
            mask9_batch = torch.repeat_interleave(mask[None,:,:],9,dim=0)[None,:,:,:].contiguous()
            transport_batch = transport.permute(2,0,1)[None,:,:,:].contiguous()

            transport_reshaped_batch = transport_batch.permute(0,2,3,1)
            transport_reshaped_batch = torch.reshape(transport_reshaped_batch, (-1, 9)).contiguous()

            zero_transport = torch.zeros_like(transport_batch.data)
            zero_albedo = torch.zeros_like(albedo_batch.data)

            for bj in range(N_train_light):
                for j in perm_light[bj:bj+1]:
                    light = train_lights[j]
                    light_batch = light.clone()

                    shading = torch.matmul(transport, light)
                    shading = torch.clamp(shading, 0., 10.)
                    shading_batch = shading.permute(2,0,1)[None,:,:,:].contiguous()

                    rendering = albedo * shading
                    rendering_batch = rendering.permute(2,0,1)[None,:,:,:].contiguous()

                    img = 2.*rendering-1.
                    img_batch = img.permute(2,0,1)[None,:,:,:].contiguous()
                    img_batch = mask3_batch * img_batch

                    transport_hat, albedo_hat, light_hat = m_shared(img_batch)


                    transport_hat = mask9_batch * transport_hat
                    L_transport = F.l1_loss(transport_hat, transport_batch)


                    transport_hat_dy = erode9_batch * F.conv2d(transport_hat, weight=v_kernel, padding=1).contiguous()
                    transport_hat_dx = erode9_batch * F.conv2d(transport_hat, weight=h_kernel, padding=1).contiguous()
                    L_transport_tv = (F.l1_loss(transport_hat_dy, zero_transport) + F.l1_loss(transport_hat_dx, zero_transport))
                    """ Use slice
                    transport_tv_x = F.l1_loss(transport_hat[:,:,1:,:],transport_hat[:,:,:-1,:])
                    transport_tv_y = F.l1_loss(transport_hat[:,:,:,1:],transport_hat[:,:,:,:-1])
                    L_transport_tv = transport_tv_x + transport_tv_y   
                    """

                    albedo_hat = mask3_batch * albedo_hat
                    L_albedo = F.l1_loss(albedo_hat, albedo_batch)
                    

                    albedo_hat_dy = erode3_batch * F.conv2d(albedo_hat, weight=v_kernel3, padding=1).contiguous()
                    albedo_hat_dx = erode3_batch * F.conv2d(albedo_hat, weight=h_kernel3, padding=1).contiguous()
                    L_albedo_tv = (F.l1_loss(albedo_hat_dy, zero_albedo) + F.l1_loss(albedo_hat_dx, zero_albedo))
                    """ Use slice
                    albedo_tv_x = F.l1_loss(albedo_hat[:,:,1:,:],albedo_hat[:,:,:-1,:])
                    albedo_tv_y = F.l1_loss(albedo_hat[:,:,:,1:],albedo_hat[:,:,:,:-1])
                    L_albedo_tv = albedo_tv_x + albedo_tv_y
                    """



                    L_light = F.l1_loss(torch.unsqueeze(light_hat, dim=0), torch.unsqueeze(light_batch, dim=0))


                    transport_reshaped_hat = transport_hat.permute(0,2,3,1)
                    transport_reshaped_hat = torch.reshape(transport_reshaped_hat, (-1, 9))
                    shading_transport_hat = torch.matmul(transport_reshaped_hat, light_batch)
                    shading_transport_hat = torch.clamp(shading_transport_hat, 0., 10.)
                    shading_transport_hat = torch.reshape(shading_transport_hat, (1, albedo.shape[0], albedo.shape[1], 3))
                    shading_transport_hat = shading_transport_hat.permute(0,3,1,2).contiguous()
                    L_shading_transport = F.l1_loss(shading_transport_hat, shading_batch)


                    shading_light_hat = torch.matmul(transport_reshaped_batch, light_hat)
                    shading_light_hat = torch.clamp(shading_light_hat, 0., 10.)
                    shading_light_hat = torch.reshape(shading_light_hat, (1, albedo.shape[0], albedo.shape[1], 3))
                    shading_light_hat = shading_light_hat.permute(0,3,1,2).contiguous()
                    L_shading_light = F.l1_loss(shading_light_hat, shading_batch)


                    shading_all_hat = torch.matmul(transport_reshaped_hat, light_hat)
                    shading_all_hat = torch.clamp(shading_all_hat, 0., 10.)
                    shading_all_hat = torch.reshape(shading_all_hat, (1, albedo.shape[0], albedo.shape[1], 3))
                    shading_all_hat = shading_all_hat.permute(0,3,1,2).contiguous()
                    L_shading_all = F.l1_loss(shading_all_hat, shading_batch)


                    rendering_albedo_hat = albedo_hat * shading_batch
                    L_rendering_albedo = F.l1_loss(rendering_albedo_hat, rendering_batch)
                    

                    rendering_transport_hat = albedo_batch * shading_transport_hat
                    L_rendering_transport = F.l1_loss(rendering_transport_hat, rendering_batch)
                    

                    rendering_light_hat = albedo_batch * shading_light_hat
                    L_rendering_light = F.l1_loss(rendering_light_hat, rendering_batch)
                    

                    rendering_albedo_transport_hat = albedo_hat * shading_transport_hat
                    L_rendering_albedo_transport = F.l1_loss(rendering_albedo_transport_hat, rendering_batch)
                    

                    rendering_transport_light_hat = albedo_batch * shading_all_hat
                    L_rendering_transport_light = F.l1_loss(rendering_transport_light_hat, rendering_batch)


                    rendering_albedo_light_hat = albedo_hat * shading_light_hat
                    L_rendering_albedo_light = F.l1_loss(rendering_albedo_light_hat, rendering_batch)
                    

                    rendering_all_hat = albedo_hat * shading_all_hat
                    L_rendering_all = F.l1_loss(rendering_all_hat, rendering_batch)


                    L = w_transport * L_transport + w_transport_tv * L_transport_tv + w_albedo * L_albedo + \
                        w_albedo_tv * L_albedo_tv + w_light * L_light + w_shading_transport * L_shading_transport + \
                        w_shading_light * L_shading_light + w_shading_all * L_shading_all + w_rendering_albedo * L_rendering_albedo + \
                        w_rendering_transport * L_rendering_transport + w_rendering_light * L_rendering_light + \
                        w_rendering_albedo_transport * L_rendering_albedo_transport + w_rendering_transport_light * L_rendering_transport_light + \
                        w_rendering_albedo_light * L_rendering_albedo_light + w_rendering_all * L_rendering_all


                    o_shared.zero_grad()
                    L.backward()
                    o_shared.step()
                    

                    L_sum += L_transport.data + L_albedo.data + L_light.data + L_transport_tv.data + L_albedo_tv.data + \
                        L_shading_transport.data + L_shading_light.data + L_shading_all.data + L_rendering_albedo.data + \
                        L_rendering_transport.data + L_rendering_light.data + L_rendering_albedo_transport.data + \
                        L_rendering_transport_light.data + L_rendering_albedo_light.data + L_rendering_all.data
                    L_transport_sum += L_transport.data
                    L_albedo_sum += L_albedo.data
                    L_light_sum += L_light.data
                    L_transport_tv_sum += L_transport_tv.data
                    L_albedo_tv_sum += L_albedo_tv.data
                    L_shading_transport_sum += L_shading_transport.data
                    L_shading_light_sum += L_shading_light.data
                    L_shading_all_sum += L_shading_all.data
                    L_rendering_albedo_sum += L_rendering_albedo.data
                    L_rendering_transport_sum += L_rendering_transport.data
                    L_rendering_light_sum += L_rendering_light.data
                    L_rendering_albedo_transport_sum += L_rendering_albedo_transport.data
                    L_rendering_transport_light_sum += L_rendering_transport_light.data
                    L_rendering_albedo_light_sum += L_rendering_albedo_light.data
                    L_rendering_all_sum += L_rendering_all.data

                    pbar.update(1)
    pbar.close()
    time_epoch = time.time() - start_epoch
    raw_L = L_sum / N_train_total
    raw_L_transport = L_transport_sum / N_train_total
    raw_L_albedo = L_albedo_sum / N_train_total
    raw_L_light = L_light_sum / N_train_total
    if gpu>-1:
        raw_L = raw_L.to("cpu")
        raw_L_transport = raw_L_transport.to("cpu")
        raw_L_albedo = raw_L_albedo.to("cpu")
        raw_L_light = raw_L_light.to("cpu")

    print('    loss[total/albedo/transport/light] = [%f,%f,%f,%f], time = %.3f [sec]' % 
        (raw_L, raw_L_albedo, raw_L_transport, raw_L_light, time_epoch))

    L_sum = 0.
    L_transport_sum = 0.
    L_albedo_sum = 0.
    L_light_sum = 0.
    L_transport_tv_sum = 0.
    L_albedo_tv_sum = 0.
    L_shading_transport_sum = 0.
    L_shading_light_sum = 0.
    L_shading_all_sum = 0.
    L_rendering_albedo_sum = 0.
    L_rendering_transport_sum = 0.
    L_rendering_light_sum = 0.
    L_rendering_albedo_transport_sum = 0.
    L_rendering_transport_light_sum = 0.
    L_rendering_albedo_light_sum = 0.
    L_rendering_all_sum = 0.    
    perm_test_img = np.random.permutation(N_test_img)
    perm_test_light = np.random.permutation(N_test_light)

    start_test = time.time()


    m_shared.train_dropout = False

    pbar = tqdm(total=N_test_total, desc='  test', ascii=True)
    for bi in range(N_test_img):
        for i in perm_test_img[bi:bi+1]:
            albedo = cv2.imread(test_fpath[i], cv2.IMREAD_COLOR).astype(np.float32) / 255.
            mask = cv2.imread(test_fpath[i][:-7]+"mask.png", cv2.IMREAD_GRAYSCALE).astype(np.float32) / 255.
            eroded_mask = skimage.morphology.binary_erosion(mask).astype(np.float32)
            transport = np.load(test_fpath[i][:-7]+"transport.npz")['T']
            
            albedo = torch.from_numpy(albedo.astype(np.float32)).clone()
            mask = torch.from_numpy(mask.astype(np.float32)).clone()
            eroded_mask = torch.from_numpy(eroded_mask.astype(np.float32)).clone()
            transport = torch.from_numpy(transport.astype(np.float32)).clone()

            if gpu>-1:
                albedo = albedo.to("cuda")
                mask = mask.to("cuda")
                eroded_mask = eroded_mask.to("cuda")
                transport = transport.to("cuda")

            with torch.no_grad():            
                albedo_batch = albedo.permute(2,0,1)[None,:,:,:]
                erode3_batch = torch.repeat_interleave(eroded_mask[None,:,:],3,dim=0)[None,:,:,:]
                erode9_batch = torch.repeat_interleave(eroded_mask[None,:,:],9,dim=0)[None,:,:,:]
                mask3_batch = torch.repeat_interleave(mask[None,:,:],3,dim=0)[None,:,:,:]
                mask9_batch = torch.repeat_interleave(mask[None,:,:],9,dim=0)[None,:,:,:]
                transport_batch = transport.permute(2,0,1)[None,:,:,:]

            transport_reshaped_batch = transport_batch.permute(0,2,3,1)
            transport_reshaped_batch = torch.reshape(transport_reshaped_batch, (-1, 9))


            transport_dy = F.conv2d(transport_batch, weight=v_kernel, padding=1)
            transport_dx = F.conv2d(transport_batch, weight=h_kernel, padding=1)
            albedo_dy = F.conv2d(albedo_batch, weight=v_kernel3, padding=1)
            albedo_dx = F.conv2d(albedo_batch, weight=h_kernel3, padding=1)
            """ Use slice
            transport_dx = F.l1_loss(transport_batch[:,:,1:,:],transport_batch[:,:,:-1,:])
            transport_dy = F.l1_loss(transport_batch[:,:,:,1:],transport_batch[:,:,:,:-1])
            albedo_dx = F.l1_loss(albedo_batch[:,:,1:,:],albedo_batch[:,:,:-1,:])
            albedo_dy = F.l1_loss(albedo_batch[:,:,:,1:],albedo_batch[:,:,:,:-1])
            """

            for bj in range(N_test_light):
                for j in perm_test_light[bj:bj+1]:

                    light = test_lights[j]
                    with torch.no_grad():
                        light_batch = light.clone()
 
                    shading = torch.matmul(transport, light)
                    shading = torch.clamp(shading, 0., 10.)
                    with torch.no_grad():
                        shading_batch = shading.permute(2,0,1)[None,:,:,:]
                    
                    rendering = albedo * shading
                    with torch.no_grad():
                        rendering_batch = rendering.permute(2,0,1)[None,:,:,:]
 
                    img = 2.*rendering-1.
                    
                    with torch.no_grad():
                        img_batch = img.permute(2,0,1)[None,:,:,:]
                    img_batch = mask3_batch * img_batch


                    transport_hat, albedo_hat, light_hat = m_shared(img_batch)


                    transport_hat = mask9_batch * transport_hat
                    L_transport = F.l1_loss(transport_hat, transport_batch)
                     
                    transport_hat_dy = F.conv2d(transport_hat, weight=v_kernel, padding=1)
                    transport_hat_dx = F.conv2d(transport_hat, weight=h_kernel, padding=1)
                    L_transport_tv = F.l1_loss(transport_hat_dy, transport_dy) + F.l1_loss(transport_hat_dx, transport_dx)
                    """ Use slice
                    transport_hat_dx = F.l1_loss(transport_hat[:,:,1:,:],transport_hat[:,:,:-1,:])
                    transport_hat_dy = F.l1_loss(transport_hat[:,:,:,1:],transport_hat[:,:,:,:-1])
                    L_transport_tv = F.l1_loss(transport_hat_dy, transport_dy) + F.l1_loss(transport_hat_dx, transport_dx)
                    """

                    albedo_hat = mask3_batch * albedo_hat
                    L_albedo = F.l1_loss(albedo_hat, albedo_batch)

                    albedo_hat_dy = F.conv2d(albedo_hat, weight=v_kernel3, padding=1)
                    albedo_hat_dx = F.conv2d(albedo_hat, weight=h_kernel3, padding=1)
                    L_albedo_tv = F.l1_loss(albedo_hat_dy, albedo_dy) + F.l1_loss(albedo_hat_dx, albedo_dx)
                    """ Use slice
                    albedo_hat_dx = F.l1_loss(albedo_hat[:,:,1:,:],albedo_hat[:,:,:-1,:])
                    albedo_hat_dy = F.l1_loss(albedo_hat[:,:,:,1:],albedo_hat[:,:,:,:-1])
                    L_albedo_tv = F.l1_loss(albedo_hat_dy, albedo_dy) + F.l1_loss(albedo_hat_dx, albedo_dx)
                    """

                    L_light = F.l1_loss(torch.unsqueeze(light_hat, dim=0), torch.unsqueeze(light_batch, dim=0))
                    
                    transport_reshaped_hat = transport_hat.permute(0,2,3,1)
                    transport_reshaped_hat = torch.reshape(transport_reshaped_hat, (-1, 9))
                    shading_transport_hat = torch.matmul(transport_reshaped_hat, light_batch)
                    shading_transport_hat = torch.clamp(shading_transport_hat, 0., 10.)
                    shading_transport_hat = torch.reshape(shading_transport_hat, (1, albedo.shape[0], albedo.shape[1], 3))
                    shading_transport_hat = shading_transport_hat.permute(0,3,1,2)
                    L_shading_transport = F.l1_loss(shading_transport_hat, shading_batch)

                    shading_light_hat = torch.matmul(transport_reshaped_batch, light_hat)
                    shading_light_hat = torch.clamp(shading_light_hat, 0., 10.)
                    shading_light_hat = torch.reshape(shading_light_hat, (1, albedo.shape[0], albedo.shape[1], 3))
                    shading_light_hat = shading_light_hat.permute(0,3,1,2)
                    L_shading_light = F.l1_loss(shading_light_hat, shading_batch)

                    shading_all_hat = torch.matmul(transport_reshaped_hat, light_hat)
                    shading_all_hat = torch.clamp(shading_all_hat, 0., 10.)
                    shading_all_hat = torch.reshape(shading_all_hat, (1, albedo.shape[0], albedo.shape[1], 3))
                    shading_all_hat = shading_all_hat.permute(0,3,1,2)
                    L_shading_all = F.l1_loss(shading_all_hat, shading_batch)

                    rendering_albedo_hat = albedo_hat * shading_batch
                    L_rendering_albedo = F.l1_loss(rendering_albedo_hat, rendering_batch)
                    
                    rendering_transport_hat = albedo_batch * shading_transport_hat
                    L_rendering_transport = F.l1_loss(rendering_transport_hat, rendering_batch)
                    
                    rendering_light_hat = albedo_batch * shading_light_hat
                    L_rendering_light = F.l1_loss(rendering_light_hat, rendering_batch)
                    
                    rendering_albedo_transport_hat = albedo_hat * shading_transport_hat
                    L_rendering_albedo_transport = F.l1_loss(rendering_albedo_transport_hat, rendering_batch)
                    
                    rendering_transport_light_hat = albedo_batch * shading_all_hat
                    L_rendering_transport_light = F.l1_loss(rendering_transport_light_hat, rendering_batch)

                    rendering_albedo_light_hat = albedo_hat * shading_light_hat
                    L_rendering_albedo_light = F.l1_loss(rendering_albedo_light_hat, rendering_batch)
                    
                    rendering_all_hat = albedo_hat * shading_all_hat
                    L_rendering_all = F.l1_loss(rendering_all_hat, rendering_batch)
                    
                    L_sum += L_transport.data + L_albedo.data + L_light.data + L_transport_tv.data + L_albedo_tv.data + \
                        L_shading_transport.data + L_shading_light.data + L_shading_all.data + L_rendering_albedo.data + \
                        L_rendering_transport.data + L_rendering_light.data + L_rendering_albedo_transport.data + \
                        L_rendering_transport_light.data + L_rendering_albedo_light.data + L_rendering_all.data
                    L_transport_sum += L_transport.data
                    L_albedo_sum += L_albedo.data
                    L_light_sum += L_light.data
                    L_transport_tv_sum += L_transport_tv.data
                    L_albedo_tv_sum += L_albedo_tv.data
                    L_shading_transport_sum += L_shading_transport.data
                    L_shading_light_sum += L_shading_light.data
                    L_shading_all_sum += L_shading_all.data
                    L_rendering_albedo_sum += L_rendering_albedo.data
                    L_rendering_transport_sum += L_rendering_transport.data
                    L_rendering_light_sum += L_rendering_light.data
                    L_rendering_albedo_transport_sum += L_rendering_albedo_transport.data
                    L_rendering_transport_light_sum += L_rendering_transport_light.data
                    L_rendering_albedo_light_sum += L_rendering_albedo_light.data
                    L_rendering_all_sum += L_rendering_all.data

                    pbar.update(1)
    pbar.close()

    m_shared.train_dropout = True

    time_test = time.time() - start_test
    raw_L = L_sum / N_test_total
    raw_L_transport = L_transport_sum / N_test_total
    raw_L_albedo = L_albedo_sum / N_test_total
    raw_L_light = L_light_sum / N_test_total
    if gpu>-1:
        raw_L = raw_L.to("cpu")
        raw_L_transport = raw_L_transport.to("cpu")
        raw_L_albedo = raw_L_albedo.to("cpu")
        raw_L_light = raw_L_light.to("cpu")
    print('    loss[total/albedo/transport/light] = [%f,%f,%f,%f], time = %.3f [sec]' % 
        (raw_L, raw_L_albedo, raw_L_transport, raw_L_light, time_test))


    # train
    
    albedo = cv2.imread(train_fpath[perm_img[0]], cv2.IMREAD_COLOR).astype(np.float32) / 255.
    mask = cv2.imread(train_fpath[perm_img[0]][:-7]+"mask.png", cv2.IMREAD_GRAYSCALE).astype(np.float32) / 255.
    transport = np.load(train_fpath[perm_img[0]][:-7]+"transport.npz")['T']
    light = np.load(train_light_fpath[perm_light[0]])
    img = albedo * np.matmul(transport, light)
    res_transport, res_albedo, res_light = infer_light_transport_albedo_and_light(img, mask)
    
    cv2.imwrite(outdir_path+("train_albedo_epoch%03d.png" % epoch), 255 * res_albedo)
    np.savez_compressed(outdir_path+"train_transport_epoch%03d.npz" % epoch, T=res_transport)   
    save_shading_image(res_transport, light, outdir_path+("train_shading_epoch%03d.png" % epoch))
    np.save(outdir_path+("train_light_epoch%03d.npy" % epoch), res_light)

    # test
    
    albedo = cv2.imread(test_fpath[perm_test_img[0]], cv2.IMREAD_COLOR).astype(np.float32) / 255.
    mask = cv2.imread(test_fpath[perm_test_img[0]][:-7]+"mask.png", cv2.IMREAD_GRAYSCALE).astype(np.float32) / 255.
    transport = np.load(test_fpath[perm_test_img[0]][:-7]+"transport.npz")['T']
    light = np.load(test_light_fpath[perm_test_light[0]])
    img = albedo * np.matmul(transport, light)
    res_transport, res_albedo, res_light = infer_light_transport_albedo_and_light(img, mask)
       
    cv2.imwrite(outdir_path+("test_albedo_epoch%03d.png" % epoch), 255 * res_albedo)
    np.savez_compressed(outdir_path+"test_transport_epoch%03d.npz" % epoch, T=res_transport)
    save_shading_image(res_transport, light, outdir_path+("test_shading_epoch%03d.png" % epoch))
    np.save(outdir_path+("test_light_epoch%03d.npy" % epoch), res_light)

    if epoch > 0 and epoch % 2 == 0:
        torch.save(m_shared.state_dict(),model_save_path % epoch)
        torch.save(o_shared.state_dict(),opt_save_path % epoch)

