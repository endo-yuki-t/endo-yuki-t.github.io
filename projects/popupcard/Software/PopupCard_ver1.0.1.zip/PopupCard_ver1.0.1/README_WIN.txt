-------------------------------------------------------------------------
An interactive design system for pop-up cards with a physical simulation 
README for WINDOWS (07/02/2011)
-------------------------------------------------------------------------

This software assists users to design original pop-up cards by using an approach 
described in the following paper:

Satoshi Iizuka, Yuki Endo, Jun Mitani, Yoshihiro Kanamori, Yukio Fukui: 
"An Interactive Design System for Pop-Up Cards with a Physical Simulation", 
The Visual Computer (Proc. of Computer Graphics International 2011), 27, 6, 605-612, 2011.

This version is not an exact implementation of this paper. Thus, it cannot be used for 
comparison between this paper and other related systems. Also, this software has not been 
completely debugged yet. There might be some bugs in the software.
You can use this software for personal purposes only. Use in commercial projects and 
redistribution are not allowed without author's permission.

====================================================

 How to design pop-up cards using this software

====================================================

The flow of designing a pop-up card using this software is as follows:

1. Select a primitive from a pre-defined primitives list.

2. Specify the location at which the primitive is to be
placed. The positions of fixed points are automatically
adjusted such that they will be able to pop-up and be
folded correctly.

3. Edit the positions, scales, and leaning angles of the primitive
through mouse operations. The system guarantees
that geometric constraints are satisfied even after these
operations.

4. Confirm the simulated motion of closing and opening the
card. When collisions between primitives or a protruding
part of primitives are detected, the system displays a
warning massage.

5. Iterate steps 1 through 4 in an arbitrary order until a desired
pop-up card is obtained.

6. Print out and assemble the templates.

If you want to preserve pop-up card data you designed, save it as *.ppb 
files by pushing the "SAVE" button. You can load and redesign it later 
by pushing the "LOAD" button.

====================================================

Personal Contact Information

====================================================

Email:

	iizuka@npal.cs.tsukuba.ac.jp	(Satoshi Iizuka)
	endo@npal.cs.tsukuba.ac.jp		(Yuki Endo)
	