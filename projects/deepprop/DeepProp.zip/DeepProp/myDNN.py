# -*- coding: utf-8 -*-
# Copyright (C) 2016 Yuki Endo

import numpy.random
import chainer, chainer.functions as F
from chainer import cuda
from chainer import optimizers

class myDNN(object):
    
    def __init__(self, x_dim = 100, y_dim = 10, patch_radius=4, channel=3, gpu=-1):
        
        self.gpu = gpu
        self.max_epochs = 20
        self.eps = 0.01
        self.gamma = 0.01
        self.batchsize = 10
        self.patch_radius = patch_radius
        self.channel = channel
        
        self.model = chainer.FunctionSet(conv1=F.Convolution2D(channel,128,3),
                                         conv2=F.Convolution2D(128,256,3),
                                         l1c=F.Linear(2, 256),
                                         l2=F.Linear(256, 256),
                                         l2c=F.Linear(256, 256),
                                         lf=F.Linear(256, y_dim))
        
        if self.gpu >= 0:
            cuda.check_cuda_available()
            cuda.get_device(self.gpu).use()
            self.model.to_gpu()

        self.optimizer = optimizers.Adam()
        self.optimizer.setup(self.model.collect_parameters())
               
    def forward(self, x_data, y_data, xc_data, train=True):
        t = chainer.Variable(y_data, volatile=not train)
        h = self.extract_intermediates(x_data, xc_data, train)
        y  = self.model.lf(h)
        return F.softmax_cross_entropy(y, t), F.accuracy(y, t)
    
    def preforward(self, x_data, y_data, train=True):
        t = chainer.Variable(y_data, volatile=not train)
        h = self.pre_extract_intermediates(x_data, train)
        y  = self.model.lf(h)
        return F.softmax_cross_entropy(y, t), F.accuracy(y, t)
    
    def extract_intermediates(self, x, xc, train=True):
        x = chainer.Variable(x, volatile=not train)
        xc = chainer.Variable(xc, volatile=not train)
        h = F.max_pooling_2d(F.relu(self.model.conv1(x)),2)
        h = F.max_pooling_2d(F.relu(self.model.conv2(h)),2)
        hc = F.relu(self.model.l1c(xc))
        h = F.relu(self.model.l2(h) +self.model.l2c(hc))
        return h
    
    def pre_extract_intermediates(self, x, train=True):
        x = chainer.Variable(x, volatile=not train)
        h = F.max_pooling_2d(F.relu(self.model.conv1(x)),2)
        h = F.max_pooling_2d(F.relu(self.model.conv2(h)),2)
        h = F.relu(self.model.l2(h))
        return h
        
    def train(self, X, Y, Xc = None, label_num=2):
        self.__init__(len(X[0]), label_num, patch_radius = self.patch_radius, gpu = self.gpu)
        N = len(X)
        X = numpy.array(X, numpy.float32).reshape(N ,self.channel,self.patch_radius*2+1,self.patch_radius*2+1)
        Y = numpy.array(Y, numpy.int32)
        
        if Xc == None:
            Xc = numpy.array([[1.,1.]]*len(X), numpy.float32)
        else:
            Xc = numpy.array(Xc, numpy.float32)

        print "Pretrain..."
        pre_loss = float("inf")
        for _ in range(self.max_epochs):
            loss_sum = 0.
            acc_sum = 0.
            denom = 0.
            perm = numpy.random.permutation(N)
            for j in range(0, N, self.batchsize):
                x_batch = X[perm[j:j + self.batchsize]]
                y_batch = Y[perm[j:j + self.batchsize]]

                if self.gpu >= 0:
                    x_batch = cuda.cupy.asarray(x_batch)
                    y_batch = cuda.cupy.asarray(y_batch)

                self.optimizer.zero_grads()
                loss ,acc = self.preforward(x_batch, y_batch)
                loss.backward()
                self.optimizer.update()
                loss_sum += loss.data
                acc_sum += acc.data
                denom += 1.
                
            loss = loss_sum/denom
            acc = acc_sum/denom
            
            if self.gpu >= 0:
                loss = cuda.to_cpu(loss)
                acc = cuda.to_cpu(acc)
            print "loss:", loss, "accuracy:", acc
            if loss < self.eps:
                break  
            if loss-pre_loss>self.gamma:
                break
            else:
                pre_loss = loss
        print "...Done"
        
        print "Finetune..."
        pre_loss = float("inf")
        for _ in range(self.max_epochs):
            loss_sum = 0.
            acc_sum = 0.
            denom = 0.
            perm = numpy.random.permutation(N)
            for j in range(0, N, self.batchsize):
                x_batch = X[perm[j:j + self.batchsize]]
                y_batch = Y[perm[j:j + self.batchsize]]
                xc_batch = Xc[perm[j:j + self.batchsize]]
                
                if self.gpu >= 0:
                    x_batch = cuda.cupy.asarray(x_batch)
                    y_batch = cuda.cupy.asarray(y_batch)
                    xc_batch = cuda.cupy.asarray(xc_batch)

                self.optimizer.zero_grads()
                loss ,acc = self.forward(x_batch, y_batch, xc_batch)
                loss.backward()
                self.optimizer.update()
                loss_sum += loss.data
                acc_sum += acc.data
                denom += 1.
                
            loss = loss_sum/denom
            acc = acc_sum/denom
            
            if self.gpu >= 0:
                loss = cuda.to_cpu(loss)
                acc = cuda.to_cpu(acc)
            print "loss:", loss, "accuracy:", acc
            if loss < self.eps:
                break  
            if loss-pre_loss>self.gamma:
                break
            else:
                pre_loss = loss
        print "...Done"
    
    def estimate(self, X, Xc=None):
        print "Estimate..."
        X = numpy.array(X, numpy.float32).reshape(len(X),self.channel,self.patch_radius*2+1,self.patch_radius*2+1)       
        if Xc == None:
            Xc = numpy.array([[1.,1.]]*len(X), numpy.float32)
        else:
            Xc = numpy.array(Xc, numpy.float32)
        
        N = len(X)
        out = list()
        perm = range(N)
        if self.gpu >= 0:
            batchsize = 1000
        else:
            batchsize = 10000
            
        for i in range(0, N, batchsize):
            x_batch = X[perm[i:i + batchsize]]
            xc_batch = Xc[perm[i:i + batchsize]]
            
            if self.gpu >= 0:
                x_batch = cuda.cupy.asarray(x_batch)
                xc_batch = cuda.cupy.asarray(xc_batch)

            h = self.extract_intermediates(x_batch, xc_batch, False)
            y  = self.model.lf(h)
            o = F.softmax(y).data
            if self.gpu>=0:
                o = cuda.to_cpu(o)
            out.extend(o.tolist())
            print len(out), "px,",
        print "...Done"
        return out
        