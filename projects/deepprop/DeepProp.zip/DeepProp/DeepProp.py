# -*- coding: utf-8 -*-
# Copyright (C) 2016 Yuki Endo

import argparse
import json, time
import numpy.random
import scipy.sparse.linalg
import sklearn.feature_extraction
import skimage.segmentation
import cv2
import myDNN

class DeepProp(object):

    def __init__(self, img_path, gpu=-1):
        self.img = cv2.imread(img_path)

        self.patch_radius = 4
        self.t_data_ratio = 0.1
        self.sp_ratio = 0.01

        self.lmbd = 10.
        self.affinity_weight = 0.01

        self.dnn = myDNN.myDNN(patch_radius=self.patch_radius, gpu=gpu)
        self.color2label=dict()
        self.label2color=dict()

    def recoloring(self, strk_path, out_path="./out.jpg"):
        #load images
        img = self.img
        strk = cv2.imread(strk_path, -1)
        mask = cv2.cvtColor(strk[:,:,3], cv2.cv.CV_GRAY2BGR)/255.
        #overlaid_img = numpy.uint8(img*(1.-mask)+strk[:,:,:3]*mask)
        print "load input"

        #extract patch features
        reflected_img = cv2.copyMakeBorder(img, self.patch_radius,self.patch_radius,self.patch_radius,self.patch_radius,cv2.BORDER_REFLECT_101)
        patch_features = sklearn.feature_extraction.image.extract_patches_2d(reflected_img/255., (self.patch_radius*2+1,self.patch_radius*2+1))

        #prepare training data
        h, w = img.shape[:2]
        X_patch = list()
        X_coord = list()
        Y_label = list()
        for y, row in enumerate(strk[:,:,3]):
            for x, val in enumerate(row):
                if val == 0 or numpy.random.rand() > self.t_data_ratio:
                    continue
                color_str = json.dumps(strk[y,x][:3].tolist())
                self.color2label[color_str] = self.color2label.get(color_str, len(self.color2label.keys()))
                X_patch.append(patch_features[y*w+x])
                X_coord.append([y/float(h-1), x/float(w-1)])
                Y_label.append(self.color2label[color_str])
        self.label2color = {v:numpy.array(json.loads(k), numpy.float) for k, v in self.color2label.items()}

        #training
        t0 = time.time()
        self.dnn.train(X_patch, Y_label, X_coord, label_num = len(self.label2color.keys()))
        print "Training Time:", time.time()-t0
        #superpixel segmentationd
        segments = skimage.segmentation.slic(img, n_segments = int(w*h*self.sp_ratio), compactness=50., enforce_connectivity=True)

        #create test data from superpixels
        spid2center=dict()
        spid2pixnum = dict()
        for y in range(h):
            for x in range(w):
                spid2center[segments[y,x]] = spid2center.get(segments[y,x], numpy.zeros(2, numpy.float)) + numpy.array([y,x], numpy.float)
                spid2pixnum[segments[y,x]] = spid2pixnum.get(segments[y,x], 0) + 1

        X_patch = list()
        X_coord = list()
        spid2featureid = dict()
        for spid in spid2center.keys():
            spid2center[spid] = spid2center[spid]/float(spid2pixnum[spid])
            X_patch.append(patch_features[int(round(spid2center[spid][0]))*w+int(round(spid2center[spid][1]))])
            X_coord.append([spid2center[spid][0]/float(h-1), spid2center[spid][1]/float(w-1)])
            spid2featureid[spid] = len(X_patch)-1

        #estimation
        t0 = time.time()
        Y_label =  self.dnn.estimate(X_patch, X_coord)
        print "Estimation Time:", time.time()-t0

        #coloring
        c_img = numpy.zeros((h,w,3), numpy.uint8)
        for y in range(h):
            for x in range(w):
                spid = segments[y,x]
                featureid = spid2featureid[spid]
                probs = Y_label[featureid]
                res_color = numpy.zeros(3, numpy.float)

                for label, prob in enumerate(probs):
                    color = self.label2color[label]
                    if color.dot(color)==0.:
                        color = img[y,x]
                    res_color += color * prob

                c_img[y,x] = numpy.uint8(res_color)

        c_img = cv2.cvtColor(c_img, cv2.cv.CV_BGR2Lab)
        img_Lab = cv2.cvtColor(img, cv2.cv.CV_BGR2Lab)
        res_img = numpy.c_[img_Lab[:,:,:1], c_img[:,:,1].reshape(h,w,1), c_img[:,:,2].reshape(h,w,1)]
        res_img = cv2.cvtColor(res_img, cv2.cv.CV_Lab2BGR)

        #post-processing
        U_list = self.postprocessing(img, [c_img[:,:,1], c_img[:,:,2]], self.lmbd, self.affinity_weight)
        res_img = numpy.c_[img_Lab[:,:,:1], U_list[0], U_list[1]]
        res_img = cv2.cvtColor(res_img, cv2.cv.CV_Lab2BGR)

        #save image
        cv2.imwrite(out_path, res_img)

    def postprocessing(self, img, Z_list, lmbd, sigma):

        h, w = img.shape[:2]
        edge_img = cv2.Canny(cv2.cvtColor(img, cv2.cv.CV_BGR2GRAY), 100, 200, L2gradient=True)
        edge_img = cv2.dilate(edge_img, numpy.ones((2,2),numpy.uint8), iterations = 2)
        normalized_img = numpy.copy(img)/255.

        b_list = list()
        for Z in Z_list:
            b_list.append(numpy.array(Z.reshape(h*w), numpy.float))

        data = list()
        row_id = list()
        col_id = list()
        for y in range(0, h):
            for x in range(0, w):
                yw = y*w
                yw_x = yw+x
                val = 0.
                if y+1<h:
                    c_vec = normalized_img[y+1,x]-normalized_img[y,x]
                    weight = lmbd*numpy.exp(-c_vec.dot(c_vec)/sigma)
                    row_id.append(yw_x)
                    col_id.append(yw_x+w)
                    data.append(-weight)
                    val += weight
                if y-1>=0:
                    c_vec = normalized_img[y-1,x]-normalized_img[y,x]
                    weight = lmbd*numpy.exp(-c_vec.dot(c_vec)/sigma)
                    row_id.append(yw_x)
                    col_id.append(yw_x-w)
                    data.append(-weight)
                    val += weight
                if x+1<w:
                    c_vec = normalized_img[y,x+1]-normalized_img[y,x]
                    weight = lmbd*numpy.exp(-c_vec.dot(c_vec)/sigma)
                    row_id.append(yw_x)
                    col_id.append(yw_x+1)
                    data.append(-weight)
                    val += weight
                if x-1>=0:
                    c_vec = normalized_img[y,x-1]-normalized_img[y,x]
                    weight = lmbd*numpy.exp(-c_vec.dot(c_vec)/sigma)
                    row_id.append(yw_x)
                    col_id.append(yw_x-1)
                    data.append(-weight)
                    val += weight

                row_id.append(yw_x)
                col_id.append(yw_x)
                if edge_img[y,x]==255:
                    data.append(val)
                    for b in b_list:
                        b[yw_x] = 0.
                else:
                    data.append(val+1.)

        A = scipy.sparse.coo_matrix((data,(row_id,col_id)),shape=(h*w,h*w))
        A = scipy.sparse.csc_matrix(A)

        U_list = list()
        for b in b_list:
            lu = scipy.sparse.linalg.splu(A)
            U = lu.solve(b)
            U = numpy.uint8(U.reshape(h,w,1))
            U_list.append(U)

        return U_list

def main():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-i', help='file path of input image', default='data/flower.jpg')
    parser.add_argument('-s', help='file path of user stroke', default='data/strk.png')
    parser.add_argument('-o', help='file path of output image', default='data/out.jpg')
    parser.add_argument('-gpu', help='GPU device specifier', default='-1')
    args = parser.parse_args()

    DP = DeepProp(img_path = args.i, gpu=int(args.gpu))
    t0 = time.time()
    DP.recoloring(strk_path = args.s, out_path=args.o)
    print "Total Time:", time.time()-t0

if __name__ == '__main__':
    main()