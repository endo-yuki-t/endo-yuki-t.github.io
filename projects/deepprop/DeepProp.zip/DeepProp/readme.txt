-------------------------------------------------------------------------
DeepProp: Extracting Deep Features from a Single Image for Edit Propagation
README (05/17/2016)
-------------------------------------------------------------------------

This code is a simplified implementation of the edit propagation method described in the following paper: 
Yuki Endo, Satoshi Iizuka, Yoshihiro Kanamori, and Jun Mitani: "DeepProp: Extracting Deep Features from a Single Image for Edit Propagation", Computer Graphics Forum (Proc. of Eurographics 2016), Vol.35, No.2, pp.189-201, Lisbon, May 2016.

The code is written in Python, and the following packages are used: 
1. Chainer. A flexible framework for deep learning. http://chainer.org
2. scikit-learn. Machine learning library in Python. http://scikit-learn.org
3. scikit-image. Image processing library in Python. http://scikit-image.org
4. OpenCV. Image processing library. http://opencv.org

How to use: 
$python DeepProp.py -i [input image] -s [stroke image] -o [output image] -gpu [GPU device specifier]

If you use GPU for DNN learning, please specify the GPU device specifier such as "-gpu 0". 

You can use this code for scientific purposes only. Use in commercial projects and redistribution are not allowed without author's permission. Please cite our paper when using this code. 

*The sample image included in the zipped file is used from the MSRA Salient Object Dataset: 
Tie Liu, Jian Sun, Nan-Ning Zheng, Xiaoou Tang, Heung-Yeung Shum. "Learning to Detect A Salient Object". IEEE CVPR 2007.

====================================================

Personal Contact Information

====================================================
Email:
	endo@npal.cs.tsukuba.ac.jp		(Yuki Endo)